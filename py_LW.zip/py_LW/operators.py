a=4
b=2

#arithmetic Operator
print("Arithmetic Operator")
print("Add",a+b)
print("Sub",a-b)
print("mul",a*b)
print("div",a/b)
print("Floor div",a//b)
print("modulous",a%b)
print("power",a**b)
print("\t")

#Assignment Operator
print("\t")
print("\t")
print("Assignment Operator")
c=1
print(c)
c+=1
print(c)
c-=1
print(c)
c*=1
print(c)
c/=1
print(c)
c//=1
print(c)
c%=1
print(c)
c**=1
print(c)
print("\t")

#Relational Operator
print("\t")
print("\t")
print("Relational Operator")
print(a==b)
print(a!=b)
print(a<b)
print(a>b)
print(a<=b)
print(a>=b)
print("\t")


#Bitwise Operator
print("\t")
print("\t")
print("Bitwise Operator")
a=2
b=7
print(a^b)
print(a|b)
print(a&b)
print(~a)
print(~b)
print(a<<b)
print(a>>b)
print("\t")

#logical Operator
print("\t")
print("\t")
print("Logical Operator")
print(a<b and a!=b)
print(a<b or a>b)
print(not(a<=b or a==b))

