num=int(input("Enter the value:"))
temp=num
var=temp
rev=0
count=0
while(temp>0):
    count+=1
    temp//=10
while(var>0):
    digit=var%10
    res=digit**count
    rev=rev+res
    var//=10
if(rev==num):
    print("It is a Armstrong number")
else:
    print("it is not a Armstrong Number")
