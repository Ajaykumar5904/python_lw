num=int(input("Enter the number"))
temp=num
sums=0
prod=1
while(temp>0):
    digit=temp%10
    sums=sums+digit
    prod=prod*digit
    temp//=10

if(sums==prod):
    print("It is spy no")

else:
    print("It is not spy no")
