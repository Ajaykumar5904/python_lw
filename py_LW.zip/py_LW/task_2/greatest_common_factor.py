print(" greatest two common factor")
n=int(input("Enter the value"))
m=int(input("Enter the value"))
if n>m:
    l=m
else:
    l=n
for i in range(l,0,-1):
    if n%i==0 and m%i==0:
        print (i)
        break
