print("First 10 natural number")
n=int(input("Enter the range:"))
for i in range(1,n+1,1):
    print(i)
