print("multiples of 2 or 3")
n=int(input("Enter the range:"))
for i in range(1,n+1,1):
    if i%2==0 or i%3==0:
        print(i)
