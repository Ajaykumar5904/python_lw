print("even number")
n=int(input("Enter the range:"))
for i in range(2,(n*2)+1,2):
    if i%2==0:
        print(i)
