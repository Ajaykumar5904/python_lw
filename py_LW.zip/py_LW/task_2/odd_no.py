print("odd numbers")
n=int(input("Enter the range:"))
for i in range(1,n*2,2):
    if i%2!=0:
        print(i)
