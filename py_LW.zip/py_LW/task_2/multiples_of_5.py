print("multiples of 5")
n=int(input("Enter the range:"))
for i in range(1,n+1,1):
    print(i*5)
