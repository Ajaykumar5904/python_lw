print("n prime number")
n=int(input("enter the range:"))
for i in range(2,n+1):
    is_prime=True
    for num in range(2,i):
        if i%num==0:
            is_prime=False
    if is_prime:
        print(i)
