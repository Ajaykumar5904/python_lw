print("Sum of digits")
n=int(input("Enter the range:"))
sums=0
while(n>0):
    digit=n%10
    sums=sums+digit
    n//=10
print(sums)
