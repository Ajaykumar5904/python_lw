print("check_prime")
n=int(input("enter the value:"))
for i in range(2,n):
    is_prime=True
    if i%n==0:
        is_prime=False
if is_prime:
    print("Yes")
else:
    print("NO")
