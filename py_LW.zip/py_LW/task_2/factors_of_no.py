print("factor of no")
n=int(input("enter the value:"))
for i in range (1,n+1):
    if n%i==0:
        print(i)
