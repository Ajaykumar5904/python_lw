print("multiples of 2")
n=int(input("Enter the range:"))
for i in range(1,n,1):
    if i%2==0:
        print(i)
