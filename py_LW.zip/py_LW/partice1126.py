#identity Operator
print("identity Operator")
a=[11,12,13,14]
b=[11,12,13,14]
c=a
print(a is b )
print(c is a)
print(c is not b)
print("\t")

#membweship Operator
print("membweship Operator")
x=["car","bike"]
print("car" in x)
print("flight" in x)
print("bike" not in x)
print("\t")


#sequential Control
print("sequential Control")
print("Hello1")
print("Hello2")
print("Hello3")
print("Hello4")
print("\t")








