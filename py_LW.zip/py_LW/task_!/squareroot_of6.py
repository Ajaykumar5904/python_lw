val=54623
temp=val//100
res=temp%10
c=res**2
print("the square root",res,"is:",c)
