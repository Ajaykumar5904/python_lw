num=5
formula=num**0.5
print("The Square Root is:", formula)
