km=2
miles=km*0.62
print(miles)
