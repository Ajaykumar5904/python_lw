a=4
b=2
c=(a+b)**2
d=(a-b)**2
e=(a**2)-(b**2)
print("First Expression:",c)
print("Second Expression:",d)
print("Third Expression:",e)
