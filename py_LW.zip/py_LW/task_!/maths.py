a=10
b=5
#addition
add=a+b
print("Addition is :",add)
#subtraction
sub=a-b
print("Subtraction is :", sub)
#multiple
mul=a*b
print("Multiplication is :", mul)
#division
div=a/b
print("Division is :",div)
#modulus
mod=a%b
print("Modulus is :",mod)
