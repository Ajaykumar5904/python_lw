num=9248
out=num%10
print("Last Digit is:", out)


#last two digit

res=num%100
print("Last Two Digit is:", res)
