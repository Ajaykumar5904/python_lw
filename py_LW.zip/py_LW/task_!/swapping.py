a=4
b=2
print("Before swapping")
print("Value of A is :",a)
print("Value of B is :",b)
#With using Third Variable
temp=a
a=b
b=temp
print("After swapping")
print("With using Third Variable")
print("Value of A is :",a)
print("Value of B is :",b)
#Without using Third Variable
(a,b)=(b,a)
print("Without using Third Variable")
print("Value of A is :",a)
print("Value of B is :",b)
