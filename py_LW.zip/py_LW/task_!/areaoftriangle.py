base=5
height=5
area=0.5*base*height
print("Area of the Triangle:",area)
