num=int(input("Enter the value: "))
if num>0:
    num= -num
print(num)
