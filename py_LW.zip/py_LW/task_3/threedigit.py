num=int(input("Enter the value:"))
c=0
while num>0:
    c+=1
    num=num/10
if c==3:
    print("It is 3 digit no")
else:
    print("It is not 3 digit no")
