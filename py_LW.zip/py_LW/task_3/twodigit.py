num=int(input("Enter the value:"))
c=0
while num>0:
    digit=num%10
    c+=1
    num=num/10
if c==2:
    print("It is two digit no")
else:
    print("It is not two digit no")
