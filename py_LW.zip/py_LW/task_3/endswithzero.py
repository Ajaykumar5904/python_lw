n=int(input("enter the number: "))
d=n%10
if d==0:
    print("The Number ends with Zero")
else:
    print("The Number ends without Zero")
