num=int(input("Enter the value:"))
if num%10==0:
    print("It is divisible of 10")
else:
    print("It is not diviisble of 10")
