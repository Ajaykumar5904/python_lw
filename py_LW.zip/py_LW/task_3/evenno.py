num=int(input("Enter the value:"))
if num%2==0:
    print("It is odd no")
else:
    print("It is even no")
