a=int(input("Enter the value:"))
b=int(input("Enter the value:"))
if(a<b):
    print("A is small")
else:
    print("B is small")
