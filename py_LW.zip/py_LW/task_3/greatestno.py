a=int(input("Enter the value:"))
b=int(input("Enter the value:"))
if(a>b):
    print("A is big")
else:
    print("B is big")
