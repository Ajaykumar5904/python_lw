n=int(input("Enter the value:"))
temp=n
c=0
while(temp>0):
    c=c+1
    temp=temp//10
res=n**c
if res>50:
    print("Its above 50")
else:
    print("Its below 50")
