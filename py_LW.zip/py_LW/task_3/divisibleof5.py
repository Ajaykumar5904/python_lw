num=int(input("Enter the value:"))
if num%5==0:
    print("It is divisible of 5")
else:
    print("It is not diviisble of 5")
