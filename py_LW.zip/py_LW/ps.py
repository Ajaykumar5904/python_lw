'''name=input("Enter your name:")
print(name)'''
'''colors=input("Enter your fav color:")
if colors=="purple":
    print("BTS")
elif colors=="yellow":
    print("csk fans")
elif colors=="black":
    print("singles")
else:
    print("mixed color")'''
condition=input("Enter your today whether condition:")
district=input("Enter your district:")
if condition=="rainny":
    if district=="salem":
        print("today is leave for salem due to raining")
    else:
        print("today is not leave for salem due to raining")
else:
    print("All district have today college")
