a=int(input("A Values:"))
b=int(input("B Values: "))
print("\n")
print("1. Addition \t 2. Subtraction \t 3. Multiplication \t 4. Division ")
print("\n")
val=int(input("Enter the Operation to be performed:"))
print("\n")
if(val==1):
    add=a+b
    print("Addition is :",add)
elif(val==2):
    sub=a-b
    print("Subtraction is :",sub)

elif(val==3):
    mul=a*b
    print("Multiplication is :",mul)

else:
    div=a/b
    print("Division is :",div)


