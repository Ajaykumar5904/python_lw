n=int(input("Enter the value"))
for num in range(2,n):
    is_prime=True
    if n%num==0:
        is_prime=False
        break
if is_prime:
    print("it is a prime number" )
else:
    print("Not a prime number")
    
