import pywhatkit as py
no=int(input("hello"))
print(no)
