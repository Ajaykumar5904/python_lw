num=int(input("Enter the value:"))
temp=num
rev=0
while(temp>0):
    digit=temp%10
    rev=rev+digit
    temp//=10

if(num%rev==0):
    print("It is Harsad Number")
else:
    print("It is not Harsad Number")
